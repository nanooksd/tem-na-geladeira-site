import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { ChefHat, Zap, Smartphone, CheckCircle2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Toaster } from '@/components/ui/toaster';

function App() {
  const { toast } = useToast();

  const handleFeatureClick = () => {
    toast({
      title: "🚧 Esta funcionalidade ainda não foi implementada—mas não se preocupe! Você pode solicitá-la no seu próximo prompt! 🚀"
    });
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        ease: "easeOut",
      },
    },
  };

  return (
    <>
      <Helmet>
        <title>Tem na Geladeira I.A. - Receitas com o que você tem em casa</title>
        <meta name="description" content="Descubra o que dá pra cozinhar com o que você já tem. Uma IA que entende seus ingredientes e sugere receitas incríveis." />
      </Helmet>
      
      <div className="min-h-screen bg-[#f9fafb] text-gray-800 font-sans flex flex-col">
        <main className="flex-grow">
          {/* Hero Section */}
          <motion.section 
            className="text-center py-20 md:py-32 px-4"
            initial="hidden"
            animate="visible"
            variants={containerVariants}
          >
            <motion.div variants={itemVariants}>
              <ChefHat className="mx-auto h-12 w-12 text-orange-500 mb-4" />
            </motion.div>
            <motion.h1 
              className="text-4xl md:text-6xl font-bold text-gray-900 mb-4 max-w-3xl mx-auto leading-tight"
              variants={itemVariants}
            >
              Descubra o que dá pra cozinhar com o que você já tem.
            </motion.h1>
            <motion.p 
              className="text-lg md:text-xl text-gray-600 mb-8 max-w-2xl mx-auto"
              variants={itemVariants}
            >
              Nossa I.A. entende os ingredientes da sua geladeira e sugere receitas deliciosas e criativas em segundos.
            </motion.p>
            <motion.div variants={itemVariants}>
              <Button 
                onClick={handleFeatureClick}
                size="lg"
                className="bg-orange-500 text-white hover:bg-orange-600 text-lg px-10 py-6 rounded-lg font-semibold shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1"
              >
                Acessar por R$37
              </Button>
              <p className="text-sm text-gray-500 mt-3">Pagamento único. Acesso vitalício.</p>
            </motion.div>
          </motion.section>

          {/* Product Image Section */}
          <motion.section 
            className="px-4"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="max-w-5xl mx-auto bg-white p-4 rounded-2xl shadow-xl border border-gray-200">
              <img 
                className="w-full rounded-xl" 
                alt="Interface da plataforma Tem na Geladeira I.A. mostrando um campo para inserir ingredientes e uma lista de receitas sugeridas"
               src="https://images.unsplash.com/photo-1604628181046-0d9fe83f65af" />
            </div>
          </motion.section>

          {/* Benefits Section */}
          <motion.section 
            className="py-20 md:py-28 px-4"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
          >
            <div className="container mx-auto max-w-4xl grid md:grid-cols-3 gap-10 text-center">
              <motion.div className="flex flex-col items-center" variants={itemVariants}>
                <Smartphone className="h-10 w-10 text-orange-500 mb-3" />
                <h3 className="text-lg font-semibold text-gray-900 mb-1">Acesso direto do navegador</h3>
                <p className="text-gray-600">Sem precisar baixar nenhum aplicativo.</p>
              </motion.div>
              <motion.div className="flex flex-col items-center" variants={itemVariants}>
                <Zap className="h-10 w-10 text-orange-500 mb-3" />
                <h3 className="text-lg font-semibold text-gray-900 mb-1">IA que entende você</h3>
                <p className="text-gray-600">Sugestões inteligentes com base nos seus ingredientes.</p>
              </motion.div>
              <motion.div className="flex flex-col items-center" variants={itemVariants}>
                <CheckCircle2 className="h-10 w-10 text-orange-500 mb-3" />
                <h3 className="text-lg font-semibold text-gray-900 mb-1">Pagamento único</h3>
                <p className="text-gray-600">Acesso vitalício, sem mensalidades ou surpresas.</p>
              </motion.div>
            </div>
          </motion.section>
        </main>

        {/* Footer */}
        <footer className="bg-gray-800 text-white py-12">
          <div className="container mx-auto px-4">
            <div className="text-center">
              <div className="flex items-center justify-center mb-6">
                <ChefHat className="w-8 h-8 text-orange-400 mr-2" />
                <span className="text-xl font-bold">Receitas IA</span>
              </div>
              
              <div className="mb-6">
                <span className="text-gray-300">Contato: </span>
                <a 
                  href="mailto:contato@receitasia.com" 
                  className="text-orange-400 hover:text-orange-300 transition-colors"
                >
                  contato@receitasia.com
                </a>
              </div>
              
              <div className="flex justify-center space-x-6 text-sm text-gray-400">
                <button onClick={handleFeatureClick} className="hover:text-white transition-colors">
                  Termos de Uso
                </button>
                <button onClick={handleFeatureClick} className="hover:text-white transition-colors">
                  Política de Privacidade
                </button>
                <button onClick={handleFeatureClick} className="hover:text-white transition-colors">
                  Suporte
                </button>
              </div>
            </div>
          </div>
        </footer>
        
        <Toaster />
      </div>
    </>
  );
}

export default App;